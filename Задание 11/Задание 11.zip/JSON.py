from tkinter import *
import json
import requests


def func():
    name=text.get()
    u = f'https://api.github.com/users/{name}'
    t = requests.get(u).json()

    info = {
        'company': t['company'],
        'created_at': t['created_at'],
        'email': t['email'],
        'id': t['id'],
        'name': t['name'],
        'url': t['url']
    }
    json_object=json.dumps(info, indent=1)
    with open('BRUH', 'w') as f:
        f.write(json_object)


okno = Tk()
okno.title("Большой брат следит за тобой")
okno.geometry('360x180')
label = Label(text = 'Введите название репозитория:')
label.grid(column=0, row=0)
text=Entry(okno, fg='white', bg='black', width='20')
text.grid(column=1,row=0)
butn=Button(okno, text='Абра-кадабра',  command=func)
butn.grid(column=1,row=1)
okno.mainloop()